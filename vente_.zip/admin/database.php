<?php

class Database
{
    private static $connection;

    public static function connect(): PDO
    {
        if (self::$connection === null) {
            $host = getenv('DB_HOST') ?: 'sql104.infinityfree.com';
            $name = getenv('DB_NAME') ?: 'if0_42048586_benimmobilier';
            $user = getenv('DB_USER') ?: 'if0_42048586';
            $password = getenv('DB_PASSWORD') ?: 'Pausedusk9819';
            $dsn = 'mysql:host=' . $host . ';dbname=' . $name . ';charset=utf8mb4';

            self::$connection = new PDO($dsn, $user, $password, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        }

        return self::$connection;
    }

    public static function disconnect(): void
    {
        self::$connection = null;
    }
}